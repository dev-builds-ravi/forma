'use client';
import { useMemo, useRef, useState } from 'react';
import { ArrowLeft, CheckCircle2, FileImage, FilePlus2, FileText, Files, LoaderCircle, LockKeyhole, RotateCw, Scissors, Trash2, UploadCloud, X } from 'lucide-react';
import { runPdfTool } from '@/lib/pdf-tools';
const configs = {
 merge:{title:'Merge PDF',desc:'Combine multiple PDFs into one file.',icon:Files,multiple:true,accept:'.pdf,application/pdf',hint:'Select two or more PDF files.'},
 split:{title:'Split PDF',desc:'Create a separate PDF for every page.',icon:Scissors,accept:'.pdf,application/pdf',hint:'One PDF will be split into individual pages and downloaded as a ZIP.'},
 extract:{title:'Extract pages',desc:'Save only the pages you need.',icon:FilePlus2,accept:'.pdf,application/pdf',hint:'Enter pages such as 1-3,5,8.'},
 delete:{title:'Delete pages',desc:'Remove selected pages from a PDF.',icon:Trash2,accept:'.pdf,application/pdf',hint:'Enter pages to remove, such as 2,4-6.'},
 rotate:{title:'Rotate PDF',desc:'Rotate every page in your document.',icon:RotateCw,accept:'.pdf,application/pdf',hint:'Choose a rotation angle.'},
 reorder:{title:'Reorder pages',desc:'Change the order of every page.',icon:FileText,accept:'.pdf,application/pdf',hint:'Enter the new page order, such as 3,1,2.'},
 images:{title:'JPG/PNG to PDF',desc:'Turn images into a single PDF.',icon:FileImage,multiple:true,accept:'image/jpeg,image/png,.jpg,.jpeg,.png',hint:'Choose one or more JPG or PNG images.'}
};
const sizeLabel = n => n<1048576 ? `${(n/1024).toFixed(0)} KB` : `${(n/1048576).toFixed(2)} MB`;
export default function ToolWorkspace({toolId,onBack}) {
 const cfg=configs[toolId], inputRef=useRef(null);
 const [selected,setSelected]=useState([]),[dragging,setDragging]=useState(false),[pages,setPages]=useState(''),[rotation,setRotation]=useState('90'),[order,setOrder]=useState(''),[busy,setBusy]=useState(false),[status,setStatus]=useState(''),[error,setError]=useState('');
 const totalSize=useMemo(()=>selected.reduce((s,f)=>s+f.size,0),[selected]);
 if(!cfg)return <section className="workspace">Tool not found. <button onClick={onBack}>Back</button></section>;
 const Icon=cfg.icon;
 function addFiles(list){const incoming=Array.from(list||[]);if(!incoming.length)return;setSelected(old=>cfg.multiple?[...old,...incoming].filter((f,i,a)=>a.findIndex(x=>x.name===f.name&&x.size===f.size)===i):[incoming[0]]);setStatus('');setError('');}
 async function process(){setBusy(true);setError('');setStatus('');try{setStatus(await runPdfTool({tool:toolId,files:selected,pages,rotation,order,onProgress:setStatus}));}catch(e){setError(e?.message||'Unable to process this file.');setStatus('');}finally{setBusy(false);}}
 return <section className="workspace">
  <button className="back-link" onClick={onBack}><ArrowLeft size={16}/> All tools</button>
  <div className="workspace-heading"><div className="tool-icon large"><Icon size={25}/></div><div><h1>{cfg.title}</h1><p>{cfg.desc}</p></div></div>
  <div className="work-card">
   <div className={`drop-zone ${dragging?'dragging':''}`} onDragOver={e=>{e.preventDefault();setDragging(true)}} onDragLeave={()=>setDragging(false)} onDrop={e=>{e.preventDefault();setDragging(false);addFiles(e.dataTransfer.files)}}>
    <div className="upload-symbol"><UploadCloud size={30}/></div><h2>Choose your files</h2><p>Drag and drop here, or browse from your device</p>
    <button className="primary-button" onClick={()=>inputRef.current?.click()}>Select files</button>
    <input ref={inputRef} type="file" hidden multiple={Boolean(cfg.multiple)} accept={cfg.accept} onChange={e=>{addFiles(e.target.files);e.target.value=''}}/>
    <span className="drop-hint">{cfg.hint}</span>
   </div>
   {selected.length>0&&<div className="file-list"><div className="file-list-title"><strong>Selected files</strong><span>{selected.length} file{selected.length===1?'':'s'} · {sizeLabel(totalSize)}</span></div>
    {selected.map((file,i)=><div className="file-row" key={`${file.name}-${file.size}-${i}`}><div className="file-type"><FileText size={18}/></div><div className="file-meta"><strong>{file.name}</strong><span>{sizeLabel(file.size)}</span></div><button className="icon-button" aria-label={`Remove ${file.name}`} onClick={()=>setSelected(all=>all.filter((_,j)=>i!==j))}><X size={17}/></button></div>)}
   </div>}
   {['extract','delete'].includes(toolId)&&<div className="option-field"><label htmlFor="pages">Page numbers / ranges</label><input id="pages" value={pages} onChange={e=>setPages(e.target.value)} placeholder="Example: 1-3, 5, 8"/><small>Page numbering starts at 1. Separate values with commas.</small></div>}
   {toolId==='rotate'&&<div className="option-field"><label htmlFor="rotation">Rotation angle</label><select id="rotation" value={rotation} onChange={e=>setRotation(e.target.value)}><option value="90">90° clockwise</option><option value="180">180°</option><option value="270">270° clockwise</option></select></div>}
   {toolId==='reorder'&&<div className="option-field"><label htmlFor="order">New page order</label><input id="order" value={order} onChange={e=>setOrder(e.target.value)} placeholder="Example: 3, 1, 2, 4"/><small>Include every page number exactly once.</small></div>}
   {error&&<div className="message error"><X size={18}/>{error}</div>}{status&&!busy&&<div className="message success"><CheckCircle2 size={18}/>{status}</div>}{busy&&<div className="message progress"><LoaderCircle size={18} className="spin"/>{status||'Processing…'}</div>}
   <button className="process-button" disabled={busy||selected.length===0} onClick={process}>{busy?<><LoaderCircle className="spin" size={18}/> Processing…</>:'Process and download'}</button>
   <p className="privacy-note"><LockKeyhole size={13}/> Files are processed in your browser and are not uploaded to FORMA.</p>
  </div>
 </section>;
}
