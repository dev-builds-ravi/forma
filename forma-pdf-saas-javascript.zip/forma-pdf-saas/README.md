# FORMA — PDF tools starter (JavaScript)

FORMA is a Next.js 15 App Router project written in **JavaScript**. It includes a responsive landing page and real, browser-local PDF operations.

## Requirements
- Node.js 20.9 or newer
- npm
- VS Code (recommended)

## Run locally
1. Extract this ZIP and open the `forma-pdf-saas` folder in VS Code.
2. Open Terminal → New Terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Visit http://localhost:3000.

For production: `npm run build` then `npm start`.

## Working tools
- Merge PDF (multiple PDFs)
- Split PDF (one PDF per page, downloaded as ZIP)
- Extract pages (page numbers and ranges, e.g. 1-3,5)
- Delete pages (page numbers and ranges)
- Rotate PDF (all pages by 90°, 180° or 270°)
- Reorder pages (enter all page numbers in desired order)
- JPG/PNG to PDF (one image per page)

## Privacy and architecture
PDF operations run client-side with `pdf-lib` and `JSZip`. Files are read from the browser's file picker and are not uploaded to an application server. There is no backend, database, authentication, payment integration or cloud storage in this starter.

## Important limitations
This is a functional MVP, not a full iLovePDF replacement. Some encrypted, malformed or feature-rich PDFs may fail or may not preserve every advanced feature. Compression, OCR, PDF-to-Word/Excel, password protection/unlock and AI document chat are not implemented. Large files can use substantial browser memory. Image conversion supports JPG/JPEG and PNG.

## Production milestones
1. Add automated tests and stronger file validation.
2. Add a server-side processing queue for heavyweight operations (e.g. Ghostscript compression), strict file-size limits and automatic deletion.
3. Add authentication, usage quotas and storage only where necessary.
4. Add monitoring, rate limiting, malware scanning and privacy/legal pages before public launch.

FORMA is a working project name. Check trademark and domain availability before commercial use.
