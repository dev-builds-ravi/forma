import './globals.css';
export const metadata = { title: 'FORMA — Documents made simple', description: 'Private PDF tools to merge, split, rotate and organize documents in your browser.' };
export default function RootLayout({ children }) { return <html lang="en"><body>{children}</body></html>; }
