'use client';
import { useState } from 'react';
import { ArrowRight, Check, ChevronRight, FileImage, FilePlus2, FileText, Files, LockKeyhole, Menu, RotateCw, Scissors, ShieldCheck, Sparkles, Trash2, X } from 'lucide-react';
import ToolWorkspace from '@/components/ToolWorkspace';
const tools=[
 {id:'merge',name:'Merge PDF',desc:'Combine PDFs in the order you choose.',icon:Files,category:'Organize'},
 {id:'split',name:'Split PDF',desc:'Separate every page into its own PDF.',icon:Scissors,category:'Organize'},
 {id:'extract',name:'Extract pages',desc:'Create a PDF from selected pages.',icon:FilePlus2,category:'Organize'},
 {id:'delete',name:'Delete pages',desc:'Remove pages you no longer need.',icon:Trash2,category:'Organize'},
 {id:'rotate',name:'Rotate PDF',desc:'Rotate all pages in your document.',icon:RotateCw,category:'Edit'},
 {id:'reorder',name:'Reorder pages',desc:'Rearrange the order of your pages.',icon:FileText,category:'Edit'},
 {id:'images',name:'JPG/PNG to PDF',desc:'Convert images into one PDF file.',icon:FileImage,category:'Convert'}
];
const categories=['All tools','Organize','Edit','Convert'];
export default function Home(){
 const [activeTool,setActiveTool]=useState(null),[category,setCategory]=useState('All tools'),[query,setQuery]=useState(''),[mobileMenu,setMobileMenu]=useState(false);
 const visible=tools.filter(t=>(category==='All tools'||t.category===category)&&`${t.name} ${t.desc}`.toLowerCase().includes(query.toLowerCase()));
 return <main>
  <header className="navbar"><a className="brand" href="#" onClick={e=>{e.preventDefault();setActiveTool(null)}}><span className="brand-mark">F</span><span>forma</span></a>
   <nav className={mobileMenu?'nav-links open':'nav-links'}><a href="#tools" onClick={()=>setMobileMenu(false)}>All tools</a><a href="#how-it-works" onClick={()=>setMobileMenu(false)}>How it works</a><a href="#privacy" onClick={()=>setMobileMenu(false)}>Privacy</a></nav>
   <button className="nav-cta" onClick={()=>{setActiveTool('merge');setMobileMenu(false)}}>Start using FORMA <ArrowRight size={15}/></button><button className="mobile-toggle" aria-label="Toggle menu" onClick={()=>setMobileMenu(v=>!v)}>{mobileMenu?<X/>:<Menu/>}</button>
  </header>
  {activeTool?<ToolWorkspace toolId={activeTool} onBack={()=>setActiveTool(null)}/>:<>
   <section className="hero"><div className="hero-copy"><div className="eyebrow"><Sparkles size={14}/> SIMPLE PDF TOOLS, RIGHT IN YOUR BROWSER</div><h1>Documents,<br/><span>made simple.</span></h1><p className="hero-description">Everything you need to work with PDFs. No complicated software, no unnecessary steps. Just get it done.</p><div className="hero-actions"><a className="primary-button" href="#tools">Explore PDF tools <ArrowRight size={17}/></a><span><ShieldCheck size={16}/> Private by design</span></div><div className="hero-proof"><div className="proof-icon"><LockKeyhole size={17}/></div><div><strong>Your files stay yours.</strong><span>Processing happens locally in your browser.</span></div></div></div>
    <div className="hero-visual" aria-label="Illustration of organized PDF documents"><div className="visual-glow"/><div className="paper paper-back"><span>PDF</span><i/><i/><i/></div><div className="paper paper-mid"><span>PDF</span><i/><i/><i/></div><div className="paper paper-front"><div className="pdf-label">PDF</div><div className="paper-lines"><i/><i/><i/><i/></div><div className="paper-check"><Check size={20}/></div></div><div className="floating-chip"><Check size={14}/> Ready when you are</div></div>
   </section>
   <section className="tools-section" id="tools"><div className="section-top"><div><div className="eyebrow">THE TOOLKIT</div><h2>All your PDF essentials.</h2><p>Useful tools. A clear interface. No learning curve.</p></div><div className="tool-count">{tools.length} tools available</div></div>
    <div className="tool-controls"><div className="category-tabs">{categories.map(c=><button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div><input className="tool-search" placeholder="Search tools..." value={query} onChange={e=>setQuery(e.target.value)}/></div>
    <div className="tool-grid">{visible.map(t=>{const Icon=t.icon;return <button className="tool-card" key={t.id} onClick={()=>setActiveTool(t.id)}><div className="tool-icon"><Icon size={21}/></div><div className="tool-card-text"><strong>{t.name}</strong><span>{t.desc}</span></div><ChevronRight className="tool-arrow" size={18}/></button>})}</div>{visible.length===0&&<div className="empty-state">No tools match “{query}”. Try another search.</div>}
   </section>
   <section className="how-section" id="how-it-works"><div className="eyebrow">NO FRICTION</div><h2>Three steps. That’s it.</h2><div className="steps"><div><span>01</span><h3>Choose a tool</h3><p>Pick the PDF action you need. Each tool does one job clearly.</p></div><div><span>02</span><h3>Add your files</h3><p>Select files from your device or drag them into the workspace.</p></div><div><span>03</span><h3>Download the result</h3><p>FORMA processes your document and saves the finished file.</p></div></div></section>
   <section className="privacy-section" id="privacy"><div className="privacy-badge"><LockKeyhole size={22}/></div><div><h2>Private from the start.</h2><p>Core PDF operations run in your browser. Your files are not sent to a FORMA server by this version of the app.</p></div><div className="privacy-points"><span><Check size={15}/> No account required</span><span><Check size={15}/> No server upload</span><span><Check size={15}/> Files stay on your device</span></div></section>
  </>}
  <footer><a className="brand footer-brand" href="#"><span className="brand-mark">F</span><span>forma</span></a><span>Documents made simple.</span><span>© {new Date().getFullYear()} FORMA. Built for clarity.</span></footer>
 </main>;
}
